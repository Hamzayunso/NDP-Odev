﻿/*************************************************************************************
*                                Sakarya Üniversitesi
*                           Bilgisayar ve Bilişim Bilimleri Fakültesi
*                           Bilişim Sistemleri Mühendisliği Bölümü
*                           Nesneye Dayalı Programlama Dersi
*                           2019-2020 Bahar Dönemi
*                           Ödev numarası: 1
*                           Öğrenci Adı: Hamza Yunso
*                           Öğrenci Numarası: B171200552
*                           Dersin Alındığı Grup: A
*
**************************************************************************************/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            int adetKaradut = 0, adetKola = 0, adetFanta = 0, adetAyran = 0, adetDoner = 0, adetCigKofte =0, adetKavurma = 0, adetAdanaKebap = 0; //Müşteri her üründen kaç tane ister
             
            if(textBox4.Text!="") //Textbox boş bırakılırsa toplam hesaplarken hata çıkmaması için
                adetKaradut = Convert.ToInt32(textBox4.Text);
            if(textBox1.Text!="")
                adetKola = Convert.ToInt32(textBox1.Text);
            if (textBox3.Text != "")
                adetFanta = Convert.ToInt32(textBox3.Text);
            if (textBox5.Text != "")
                adetAyran = Convert.ToInt32(textBox5.Text);
            if (textBox2.Text != "")
                adetDoner = Convert.ToInt32(textBox2.Text);
            if (textBox9.Text != "")
                adetCigKofte = Convert.ToInt32(textBox9.Text);
            if (textBox7.Text != "")
                adetKavurma = Convert.ToInt32(textBox7.Text);
            if (textBox6.Text != "")
                adetAdanaKebap = Convert.ToInt32(textBox6.Text); 
            //Ürünleri Tanımlama
            int karadut = Convert.ToInt32(label23.Text);
            int kola = Convert.ToInt32(label22.Text);
            int fanta = Convert.ToInt32(label21.Text);
            int ayran = Convert.ToInt32(label20.Text);
            int doner = Convert.ToInt32(label16.Text);
            int cigKofte = Convert.ToInt32(label17.Text);
            int kavurma = Convert.ToInt32(label18.Text);
            int adanaKebap = Convert.ToInt32(label19.Text);
            //Sonuç değişkeni Ödeme tutarı gösteriyor
            int sonuc = (adetKaradut*karadut) + (adetKola*kola) + (adetFanta*fanta) + (adetAyran*ayran) + (adetDoner*doner) + 
                (adetCigKofte*cigKofte) + (adetKavurma*kavurma) + (adetAdanaKebap*adanaKebap);
            string para = "\n TL";
            textBox8.Text = sonuc.ToString() + "\n" + para;

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
